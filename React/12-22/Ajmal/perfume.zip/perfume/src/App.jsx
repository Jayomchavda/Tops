import './App.css'
import "react-multi-carousel/lib/styles.css";
import Router from './router/Router';




function App() {

  return (
    <div >
      <Router />
    </div >
  )
}

export default App
